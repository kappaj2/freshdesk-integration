package za.co.sfh.fresh;

public interface IntegrationTest {
}
