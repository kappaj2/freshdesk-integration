package za.co.sfh.fresh;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import za.co.sfh.fresh.service.crm.CRMManagementService;

import java.util.Optional;

@TestConfiguration
public class SetupTestConfiguration {

     @Primary
     @Bean
     public CRMManagementService getCRMManagementService() {
          CRMManagementService service = alpha2Code -> Optional.empty();
          return service;
     }
}
