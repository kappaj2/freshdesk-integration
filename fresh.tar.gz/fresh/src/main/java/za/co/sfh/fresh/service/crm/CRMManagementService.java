package za.co.sfh.fresh.service.crm;

import za.co.sfh.fresh.service.crm.webclient.dto.CRMCountry;

import java.util.Optional;

public interface CRMManagementService {
     Optional<CRMCountry> retrieveCountryForAlpha2Code(String alpha2Code);
}
