package za.co.sfh.fresh.aws.receiver;

import za.co.sfh.fresh.aws.dto.FreshDeskPayload;
import za.co.sfh.fresh.exception.CustomerNotActiveException;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;

public interface AWSQueueMessageHandler {

     void processMessageReceived(FreshDeskPayload freshdeskPayload, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException, CustomerNotActiveException;

}
