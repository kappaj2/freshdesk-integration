package za.co.sfh.fresh.aws.receiver.handlers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import za.co.sfh.fresh.aws.dto.FreshDeskPayload;
import za.co.sfh.fresh.aws.receiver.AWSQueueMessageHandler;
import za.co.sfh.fresh.exception.CustomerNotActiveException;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;

@Slf4j
@Service
@RequiredArgsConstructor
public class AgentUpdateMessageHandler implements AWSQueueMessageHandler {
     @Override
     public void processMessageReceived(FreshDeskPayload freshdeskPayload, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException, CustomerNotActiveException {
          log.info("Handler for update agent not implemented.");
     }
}
