package za.co.sfh.fresh.service.freshdesk;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import za.co.sfh.fresh.repository.FreshDeadLetterMessageRepository;
import za.co.sfh.fresh.repository.FreshDetailProcessingRepository;
import za.co.sfh.fresh.repository.FreshReceivedMessageRepository;

import java.util.Calendar;
import java.util.Date;

@Service
@Slf4j
@RequiredArgsConstructor
public class DatabaseMaintenanceService {

     @Value("${freshdesk.maintenance.db.days-to-keep}")
     private Integer numDaysToKeep;

     private final FreshReceivedMessageRepository freshReceivedMessageRepository;
     private final FreshDetailProcessingRepository freshDetailProcessingRepository;
     private final FreshDeadLetterMessageRepository freshDeadLetterMessageRepository;

     @Transactional(propagation = Propagation.REQUIRED)
     public void cleanOldMessageRecords() {
          Calendar cal = Calendar.getInstance();
          cal.set(Calendar.HOUR_OF_DAY, 0);
          cal.set(Calendar.MINUTE, 0);
          cal.set(Calendar.SECOND, 0);
          cal.set(Calendar.MILLISECOND, 0);

          cal.add(Calendar.DATE, numDaysToKeep * -1);
          Date beforeDate = cal.getTime();

          log.info("Deleting before date : {}", beforeDate);
          freshDeadLetterMessageRepository.deleteByDateCreatedBefore(beforeDate);
          freshDetailProcessingRepository.deleteByDateCreatedBefore(beforeDate);
          freshReceivedMessageRepository.deleteByDateCreatedBefore(beforeDate);
     }
}
