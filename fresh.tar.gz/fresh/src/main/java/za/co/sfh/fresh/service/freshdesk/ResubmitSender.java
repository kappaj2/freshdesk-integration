package za.co.sfh.fresh.service.freshdesk;

public interface ResubmitSender {
     void processResubmitRequest(String awsMessageId);
}
