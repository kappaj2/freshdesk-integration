package za.co.sfh.fresh.aws.receiver.handlers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.sfh.fresh.aws.dto.FreshDeskPayload;
import za.co.sfh.fresh.aws.receiver.AWSQueueMessageHandler;
import za.co.sfh.fresh.aws.receiver.mapper.ContactDTOMapper;
import za.co.sfh.fresh.exception.CustomerNotActiveException;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.FreshMessageType;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;
import za.co.sfh.fresh.service.freshdesk.ContactManagementService;
import za.co.sfh.fresh.service.restclient.payloads.FreshContact;
import za.co.sfh.fresh.service.restclient.payloads.FreshContactView;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContactUpdateMessageHandler implements AWSQueueMessageHandler {

     private final ContactManagementService contactManagementService;
     private final ContactDTOMapper contactDTOMapper;

     @Override
     @Transactional
     public void processMessageReceived(FreshDeskPayload freshdeskPayload, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException, CustomerNotActiveException {

          if (freshdeskPayload.getFreshMessageType() != FreshMessageType.CUSTOMER_UPDATE) {
               return;
          }
          log.info("Received ContactUpdate message");

          Optional<FreshContact> freshContactOpt = contactDTOMapper.mapDtoFromMessagePayload(freshdeskPayload);
          //contactManagementService.createFreshContactDTOFromCRMPayload(freshdeskPayload);

          if (freshContactOpt.isEmpty()) {
               log.error("Error extracting the Freshdesk Contact object from the Queue payload. ");
               throw new FreshdeskProcessorException("Unable to extract the correct payload for message id " + freshReceivedMessageEntity.getFreshMessageId());
          }

          FreshContact freshContact = freshContactOpt.get();
          // Try and retrieve the contact using the unique_external_id
          log.info("Trying to retrieve contact by external id : {}", freshContact.getUniqueExternalId());

          //   Let's check if Freshdesk knows about this contact
          Optional<FreshContactView> freshContactViewOpt = contactManagementService.retrieveContactByExternalId(freshContact.getUniqueExternalId());

          if (!freshContactViewOpt.isPresent()) {
               //   Call create process.
               contactManagementService.createFreshdeskContact(freshContact, freshReceivedMessageEntity);

          } else {
               FreshContactView freshContactView = freshContactViewOpt.get();
               //   Update existing object with new values received.
               freshContactView.setEmail(freshContact.getEmail());
               freshContactView.setMobile(freshContact.getMobile());
               freshContactView.setPhone(freshContact.getPhone());
               freshContactView.setAddress(freshContact.getAddress());

               contactManagementService.updateFreshdeskContact(freshContactView, freshContact, freshReceivedMessageEntity);
          }
     }
}
