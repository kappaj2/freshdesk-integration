package za.co.sfh.fresh.service.restclient;

import org.springframework.http.HttpMethod;
import za.co.sfh.fresh.service.restclient.payloads.FreshDeskRequestPayload;
import za.co.sfh.fresh.service.restclient.payloads.FreshDeskResponsePayload;

public interface RestTemplateHandler {

     <Req extends FreshDeskRequestPayload> FreshDeskResponsePayload submitFreshdeskRequest(HttpMethod httpMethod,
                                                                                           Req freshDeskRequestPayload,
                                                                                           String uri);

     void deleteContact(String uri);
}
