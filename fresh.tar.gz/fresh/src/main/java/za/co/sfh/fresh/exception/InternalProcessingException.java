package za.co.sfh.fresh.exception;

public class InternalProcessingException extends RuntimeException {

     public InternalProcessingException(String message, Throwable cause) {
          super(message, cause);
     }
}
