package za.co.sfh.fresh.aws.receiver.mapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import za.co.sfh.fresh.aws.dto.CustomerDTO;
import za.co.sfh.fresh.aws.dto.FreshDeskPayload;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.service.crm.CRMManagementService;
import za.co.sfh.fresh.service.crm.webclient.dto.CRMCountry;
import za.co.sfh.fresh.service.restclient.payloads.FreshContact;

import java.util.Arrays;
import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class ContactDTOMapper {

     private final CRMManagementService crmManagementService;
     private final ObjectMapper objectMapper;

     public Optional<FreshContact> mapDtoFromMessagePayload(FreshDeskPayload freshDeskPayload) throws FreshdeskProcessorException {

          if (freshDeskPayload.getMessagePayload().isEmpty()) {
               return Optional.empty();
          }

          try {
               String messagePayload = freshDeskPayload.getMessagePayload();
               CustomerDTO customerDTO = objectMapper.readValue(messagePayload, CustomerDTO.class);

               FreshContact freshContact = new FreshContact();
               freshContact.setPhone(customerDTO.getCellNumber());
               freshContact.setMobile(customerDTO.getCellNumber());
               freshContact.setName(buildConcatenatedString(customerDTO.getName(), customerDTO.getSurname()));
               freshContact.setEmail(customerDTO.getEmail());
               freshContact.setUniqueExternalId(customerDTO.getId().toString());

               /*
                    Add custom field values. These are user defined fields that is allowed by Freshdesk.
                    Set country_of_residence
                */
               Optional<CRMCountry> crmCountry = crmManagementService.retrieveCountryForAlpha2Code(customerDTO.getCountryCode());
               if (crmCountry.isPresent()) {
                    freshContact.getCustomFields().put("country_of_residence", crmCountry.get().getCountryDisplayName());
               }

               return Optional.of(freshContact);

          } catch (Exception ex) {
               log.error("Error processing payload received. ", ex);
               throw new FreshdeskProcessorException("Error processing payload received.");
          }
     }

     private String buildConcatenatedString(String... args) {
          StringBuilder stringBuilder = new StringBuilder();

          Arrays.stream(args).forEach(en ->
                  stringBuilder.append(en).append(" ")
          );
          return stringBuilder.toString().trim();
     }
}
