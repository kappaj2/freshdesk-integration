package za.co.sfh.fresh.service.restclient.payloads;

public interface FreshDeskRequestPayload {
}
