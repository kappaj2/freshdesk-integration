package za.co.sfh.fresh.service.freshdesk;

import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import za.co.sfh.fresh.config.AWSProperties;
import za.co.sfh.fresh.repository.FreshDeadLetterMessageRepository;
import za.co.sfh.fresh.repository.FreshDetailProcessingRepository;
import za.co.sfh.fresh.repository.FreshReceivedMessageRepository;
import za.co.sfh.fresh.repository.MessageStatus;
import za.co.sfh.fresh.repository.entity.FreshDeadLetterMessageEntity;
import za.co.sfh.fresh.repository.entity.FreshDetailProcessingEntity;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class ResubmitSenderImpl implements ResubmitSender {

     private final AmazonSQSAsync amazonSQSAsync;
     private final FreshReceivedMessageRepository freshReceivedMessageRepository;
     private final FreshDeadLetterMessageRepository freshDeadLetterMessageRepository;
     private final FreshDetailProcessingRepository freshDetailProcessingRepository;
     private final AWSProperties awsProperties;

     @Value("${cloud.aws.end-point.uri}")
     private String awsSqsUrl;

     /**
      * Process a resubmit request. This method is called when the create/update of contact or agent has failed.
      *
      * @param awsMessageId The original message id in the fresh_received_messages table.
      */
     @Override
     public void processResubmitRequest(String awsMessageId) {
          log.info("Doing a processResubmitRequest request for awsMessageId : {}", awsMessageId);

          FreshReceivedMessageEntity receivedMessageEntity = freshReceivedMessageRepository.findByAwsQueueMessageId(awsMessageId).get();

          /*
               Check if the last status code from Freshdesk should be re-processed. This is for rate limiting, system exception etc.
           */
          boolean shouldResubmit = shouldTheRecordBeReprocessed(receivedMessageEntity.getFreshMessageId());

          if (!shouldResubmit) {
               log.info("Last Freshdesk response code indicates we will not be reprocessing the request");
               receivedMessageEntity.setMessageStatus(MessageStatus.FRESH_EXCEPTION);
               receivedMessageEntity.setDateModified(new Date());
               freshReceivedMessageRepository.save(receivedMessageEntity);

               insertDeadLetter(receivedMessageEntity, MessageStatus.FRESH_EXCEPTION);
               return;
          }

          int retryCount = receivedMessageEntity.getRetryCount();

          if (retryCount >= awsProperties.getAws().getSqs().getMaxRetryCount()) {
               log.error("Reached try count limit of {} ! Stop retrying.", awsProperties.getAws().getSqs().getMaxRetryCount());
               receivedMessageEntity.setMessageStatus(MessageStatus.REACHED_RETRY_LIMIT);
               receivedMessageEntity.setDateModified(new Date());
               freshReceivedMessageRepository.save(receivedMessageEntity);

               insertDeadLetter(receivedMessageEntity, MessageStatus.REACHED_RETRY_LIMIT);
               return;
          }

          int retryDelay = receivedMessageEntity.getLastDelayTime();
          retryCount++;

          if (retryDelay > awsProperties.getAws().getSqs().getMaxDelaySeconds()) {
               retryDelay = awsProperties.getAws().getSqs().getMaxDelaySeconds();
          } else {
               retryDelay = retryDelay + awsProperties.getAws().getSqs().getRetryDelayIncrement();
          }

          receivedMessageEntity.setRetryCount(retryCount);
          receivedMessageEntity.setLastDelayTime(retryDelay);

          freshReceivedMessageRepository.save(receivedMessageEntity);

          Map<String, MessageAttributeValue> valueMap = new HashMap<>();
          valueMap.put("previousAWSMessageId", new MessageAttributeValue()
                  .withStringValue(receivedMessageEntity.getAwsQueueMessageId())
                  .withDataType("String"));

          SendMessageRequest sendMessageRequest = new SendMessageRequest(awsSqsUrl, receivedMessageEntity.getMessagePayload())
                  .withDelaySeconds(receivedMessageEntity.getLastDelayTime())
                  .withMessageAttributes(valueMap);

          SendMessageResult sendMessageResult = amazonSQSAsync.sendMessage(sendMessageRequest);

          log.info("Resubmitted message id : {}", sendMessageResult.getMessageId());
     }

     public boolean shouldTheRecordBeReprocessed(Integer freshMessageId) {
          log.info("Searching for last activity record for freshMessageId : {}", freshMessageId);

          Optional<FreshDetailProcessingEntity> lastDetailRecordOpt = freshDetailProcessingRepository.findLastDetailRecord(freshMessageId);
          if (lastDetailRecordOpt.isPresent()) {
               FreshDetailProcessingEntity entity = lastDetailRecordOpt.get();
               Integer responseCode = entity.getFreshResponseCode();
               log.info("Found last fresh response code : {}", responseCode);
               switch (responseCode) {
                    case 409: // Duplicate value exception. Contact exists.
                         return false;
                    case 400:
                         return false;  // Data validation error.
                    case 429: // Rate limit reached
                    case 500: // Network timeout, etc
                         return true;
                    default:
                         return true;
               }

          } else {
               log.error("Error checking last message action for freshMessageId : {}", freshMessageId);
               //   TODO - more handling...
               return false;
          }
     }

     private void insertDeadLetter(FreshReceivedMessageEntity receivedMessageEntity, MessageStatus messageStatus) {
          FreshDeadLetterMessageEntity freshDeadLetterMessageEntity = new FreshDeadLetterMessageEntity();
          freshDeadLetterMessageEntity.setDateCreated(new Date());
          freshDeadLetterMessageEntity.setDateModified(new Date());
          freshDeadLetterMessageEntity.setEmailReported(Boolean.FALSE);
          freshDeadLetterMessageEntity.setLastStatus(messageStatus);
          freshDeadLetterMessageEntity.setFreshReceivedMessageEntity(receivedMessageEntity);
          freshDeadLetterMessageRepository.save(freshDeadLetterMessageEntity);
     }
}
