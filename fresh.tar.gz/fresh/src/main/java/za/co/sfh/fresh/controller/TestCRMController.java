package za.co.sfh.fresh.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import za.co.sfh.fresh.service.crm.CRMManagementService;
import za.co.sfh.fresh.service.crm.webclient.dto.CRMCountry;

import java.util.Optional;

@RestController
@Slf4j
@RequestMapping("/api/v1/crm/test/country")
@RequiredArgsConstructor
public class TestCRMController {

     private final CRMManagementService crmManagementService;

     @GetMapping("/{country-code}")
     public ResponseEntity<CRMCountry> testGetCountryCode(@PathVariable("country-code") String countryCode) {
          Optional<CRMCountry> crmCountry = crmManagementService.retrieveCountryForAlpha2Code(countryCode);
          return ResponseEntity.ok(crmCountry.get());
     }
}
