package za.co.sfh.fresh.service.freshdesk;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.FreshMessageType;
import za.co.sfh.fresh.repository.FreshReceivedMessageRepository;
import za.co.sfh.fresh.repository.MessageStatus;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;
import za.co.sfh.fresh.service.restclient.RestTemplateHandler;
import za.co.sfh.fresh.service.restclient.payloads.FreshContact;
import za.co.sfh.fresh.service.restclient.payloads.FreshContactView;
import za.co.sfh.fresh.service.restclient.payloads.FreshDeskResponsePayload;
import za.co.sfh.fresh.service.restclient.payloads.FreshErrorResponse;
import za.co.sfh.fresh.service.restclient.payloads.RestResponsePayload;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class ContactManagementServiceImpl extends ContactMessageRecorder implements ContactManagementService {

     private static final String ENDPOINT = "/api/v2/contacts";
     private final RestTemplateHandler restTemplateHandler;
     private final ObjectMapper objectMapper;
     private final FreshReceivedMessageRepository freshReceivedMessageRepository;
     private final ResubmitSender resubmitSender;

     @Override
     public Optional<FreshContactView> retrieveContactByEmailAddress(String emailAddress) {
          String searchEndpoint = ENDPOINT.concat("?email=").concat(emailAddress);
          return doUniqueFieldSearchCall(searchEndpoint);
     }

     @Override
     public Optional<FreshContactView> retrieveContactByMsisdn(String msisdn) {
          String searchEndpoint = ENDPOINT.concat("?phone=").concat(msisdn);
          return doUniqueFieldSearchCall(searchEndpoint);
     }

     @Override
     public Optional<FreshContactView> retrieveContactByExternalId(String externalId) {
          String searchEndpoint = ENDPOINT.concat("?unique_external_id=").concat(externalId);
          return doUniqueFieldSearchCall(searchEndpoint);
     }

     @Override
     public List<FreshContactView> retrieveListOfContacts() {
          FreshDeskResponsePayload freshdeskResponsePayload
                  = restTemplateHandler.submitFreshdeskRequest(HttpMethod.GET, null, ENDPOINT);
          if (freshdeskResponsePayload instanceof RestResponsePayload) {
               return parseContactSearchResult((RestResponsePayload) freshdeskResponsePayload);
          } else {
               return new ArrayList<>();
          }
     }

     @Override
     public void deleteAllContacts() {

          List<FreshContactView> freshContactViewList = retrieveListOfContacts();
          log.info("Found contacts list size : {}", freshContactViewList.size());

          freshContactViewList.forEach(cont -> {
               log.info("Deleting contact with id : {} and name : {}", cont.getId(), cont.getName());
               String url = ENDPOINT + "/" + cont.getId() + "/hard_delete?force=true";
               restTemplateHandler.deleteContact(url);
          });

     }

//     @Override
//     public Optional<FreshContact> createFreshContactDTOFromCRMPayload(FreshDeskPayload freshDeskPayload) throws FreshdeskProcessorException, CustomerNotActiveException {
//
//          if (freshDeskPayload.getMessagePayload().isEmpty()) {
//               return Optional.empty();
//          }
//
//          try {
//               CustomerDTO customerDTO = objectMapper.readValue(freshDeskPayload.getMessagePayload(), CustomerDTO.class);
//
//               //   if the customer is not active then we don't send this to Freshdesk
//               if (customerDTO.getCustomerStatus() != CustomerStatusEnum.ACTIVE) {
//                    throw new CustomerNotActiveException("Customer not active. Not submitting to Freshdesk");
//               }
//
//               FreshContact freshContact = new FreshContact();
//
//               //   Set dummy fields
//               freshContact.setAddress("Dummy address");
//
//               //   Set received fields
//               freshContact.setEmail(customerDTO.getEmail());
//               freshContact.setName(customerDTO.getName() + " " + customerDTO.getSurname());
//               freshContact.setMobile(customerDTO.getCellNumber());
//               freshContact.setPhone(customerDTO.getCellNumber());
//               freshContact.setUniqueExternalId(customerDTO.getId().toString());
//
//               //   Set custom fields
//               freshContact.getCustomFields().put("customer_status", customerDTO.getCustomerStatus().name());
//
//               //   Set custom tags
//               List<String> tagsList = new ArrayList<>();
//               tagsList.add("Custom tag 1");
//               tagsList.add("Custom tag 2");
//
//               return Optional.of(freshContact);
//
//          } catch (CustomerNotActiveException cna) {
//               log.error(cna.getMessage());
//               throw cna;
//          } catch (Exception ex) {
//               log.error("Processing error create FreshContact object from the DTO received", ex);
//               throw new FreshdeskProcessorException("Error processing payload");
//          }
//     }

     @Override
     public void createFreshdeskContact(FreshContact freshContact, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException {

          FreshDeskResponsePayload freshdeskResponsePayload
                  = restTemplateHandler.submitFreshdeskRequest(HttpMethod.POST, freshContact, ENDPOINT);

          /*
               For this we should get back a 201 response code.
           */
          if (freshdeskResponsePayload instanceof FreshErrorResponse) {
               log.info("Received an error response from Freshdesk");

               FreshErrorResponse freshErrorResponse = (FreshErrorResponse) freshdeskResponsePayload;
               log.info("Error response calling create of contact : {}", freshErrorResponse);

               recordMessageProcessingDetails(freshContact, freshdeskResponsePayload, freshReceivedMessageEntity, FreshMessageType.CUSTOMER_CREATION);

               //   If it is error 409, then it is a duplicate contact. Switch to update contact mode.
               if (freshErrorResponse.getResponseCode().equals(409)) {
                    Optional<FreshContactView> existingFreshContactViewOpt = retrieveContactByExternalId(freshContact.getUniqueExternalId());

                    if (existingFreshContactViewOpt.isPresent()) {
                         FreshContactView freshContactView = existingFreshContactViewOpt.get();
                         String id = freshContactView.getId();

                         freshdeskResponsePayload
                                 = restTemplateHandler.submitFreshdeskRequest(HttpMethod.PUT, freshContact, ENDPOINT + "/" + id);
                         recordMessageProcessingDetails(freshContact, freshdeskResponsePayload, freshReceivedMessageEntity, FreshMessageType.CUSTOMER_UPDATE);

                         /*
                              If this was a success - then update master as
                          */
                         if (freshdeskResponsePayload instanceof RestResponsePayload) {
                              freshReceivedMessageEntity.setMessageStatus(MessageStatus.CONTACT_UPDATED);
                              freshReceivedMessageEntity.setDateModified(new Date());
                              freshReceivedMessageRepository.save(freshReceivedMessageEntity);

                              // response code of 200 indicates successful update
                              if (((RestResponsePayload) freshdeskResponsePayload).getResponseCode() < 300) {
                                   return;
                              }
                         }
                    }
               }

               /*
                    Retry if the response code is not in the 200 range.
                    This will check for rate limit errors so we can backoff and retry again.
                    Also handle possible network error responses, etc.
                */
               if (freshErrorResponse.getResponseCode() >= 300) {
                    log.info("Total failure for create / update. Doing processResubmitRequest");
                    resubmitSender.processResubmitRequest(freshReceivedMessageEntity.getAwsQueueMessageId());
               }
          } else {
               log.info("Received success response from Freshdesk");
               // success - update master record.
               freshReceivedMessageEntity.setMessageStatus(MessageStatus.CONTACT_CREATED);
               freshReceivedMessageEntity.setDateModified(new Date());
               freshReceivedMessageRepository.save(freshReceivedMessageEntity);

               recordMessageProcessingDetails(freshContact, freshdeskResponsePayload, freshReceivedMessageEntity, FreshMessageType.CUSTOMER_CREATION);
          }
     }

     @Override
     public void updateFreshdeskContact(FreshContactView freshContactView, FreshContact freshContact, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException {

          FreshDeskResponsePayload freshdeskResponsePayload
                  = restTemplateHandler.submitFreshdeskRequest(HttpMethod.PUT, freshContact, ENDPOINT + "/" + freshContactView.getId());

          //   Error response
          if (freshdeskResponsePayload instanceof FreshErrorResponse) {

               FreshErrorResponse freshErrorResponse = (FreshErrorResponse) freshdeskResponsePayload;
               log.info("Error response calling update of customer : {}", freshErrorResponse);

               recordMessageProcessingDetails(freshContact, freshdeskResponsePayload, freshReceivedMessageEntity, FreshMessageType.CUSTOMER_UPDATE);

                    /*
                         Retry if the response code is not in the 200 range.
                    */
               if (freshErrorResponse.getResponseCode() >= 300) {
                    resubmitSender.processResubmitRequest(freshReceivedMessageEntity.getAwsQueueMessageId());
               }

          } else { // success response
               // success - update master record.
               freshReceivedMessageEntity.setMessageStatus(MessageStatus.CONTACT_UPDATED);
               freshReceivedMessageEntity.setDateModified(new Date());
               freshReceivedMessageRepository.save(freshReceivedMessageEntity);

               recordMessageProcessingDetails(freshContact, freshdeskResponsePayload, freshReceivedMessageEntity, FreshMessageType.CUSTOMER_UPDATE);
          }
     }

     private Optional<FreshContactView> doUniqueFieldSearchCall(String searchEndpoint) {

          FreshDeskResponsePayload freshdeskResponsePayload
                  = restTemplateHandler.submitFreshdeskRequest(HttpMethod.GET, null, searchEndpoint);

          if (freshdeskResponsePayload instanceof RestResponsePayload) {
               RestResponsePayload restResponsePayload = (RestResponsePayload) freshdeskResponsePayload;
               List<FreshContactView> freshContactViewList = parseContactSearchResult(restResponsePayload);
               if (!freshContactViewList.isEmpty()) {
                    return Optional.of(freshContactViewList.get(0));
               }
          }
          return Optional.empty();
     }

     private List<FreshContactView> parseContactSearchResult(RestResponsePayload restResponsePayload) {
          try {
               FreshContactView[] freshContactViewArr = objectMapper.readValue(restResponsePayload.getResponseMessage(), FreshContactView[].class);
               return Arrays.asList(freshContactViewArr);

          } catch (JsonProcessingException jp) {
               log.error("Error processing response message", jp);
          }
          return new ArrayList<>();
     }
}
