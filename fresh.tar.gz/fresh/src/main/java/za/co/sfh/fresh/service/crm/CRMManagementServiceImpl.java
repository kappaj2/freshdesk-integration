package za.co.sfh.fresh.service.crm;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import za.co.sfh.fresh.service.crm.webclient.CRMWebClientHandler;
import za.co.sfh.fresh.service.crm.webclient.dto.CRMCountry;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.StampedLock;

@Slf4j
@Service
@RequiredArgsConstructor
public class CRMManagementServiceImpl implements CRMManagementService {

     private static Map<String, CRMCountry> countriesMap = new HashMap<>();
     private StampedLock stampedLock = new StampedLock();
     private final CRMWebClientHandler crmWebClientHandler;

     @Override
     public Optional<CRMCountry> retrieveCountryForAlpha2Code(String alpha2Code) {
          log.debug("Retrieving county for code : {}", alpha2Code);
          if (countriesMap.size() == 0 || !countriesMap.containsKey(alpha2Code)) {
               log.info("Retry to fetch CountriesMap from crm module. Current map size : {}", countriesMap.size());
               long stamp = stampedLock.readLock();
               try {
                    populateCountriesMap();
               } finally {
                    stampedLock.unlockRead(stamp);
               }
          }
          return Optional.ofNullable(countriesMap.get(alpha2Code));
     }

     private void populateCountriesMap() {
          log.info("Retrieving list of countries from CRM module");
          String crmCountriesEndpoint = "/api/v1/countries";
          ParameterizedTypeReference<List<CRMCountry>> parameterizedTypeReference =
                  new ParameterizedTypeReference<>() {
                  };

          Mono<List<CRMCountry>> countriesListMono
                  = crmWebClientHandler.fetchList(parameterizedTypeReference, builder -> builder.path(crmCountriesEndpoint).build());

          List<CRMCountry> countryList = countriesListMono.block();
          log.info("Country list is : {}", countryList);
          countryList.stream().forEach(country -> countriesMap.put(country.getCountryCode(), country));
     }
}
