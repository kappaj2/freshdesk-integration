package za.co.sfh.fresh.aws.receiver.handlers;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import za.co.sfh.fresh.aws.dto.FreshDeskPayload;
import za.co.sfh.fresh.aws.receiver.AWSQueueMessageHandler;
import za.co.sfh.fresh.aws.receiver.mapper.ContactDTOMapper;
import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.FreshMessageType;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;
import za.co.sfh.fresh.service.freshdesk.ContactManagementService;
import za.co.sfh.fresh.service.restclient.payloads.FreshContact;

import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ContactCreateMessageHandler implements AWSQueueMessageHandler {

     private final ContactManagementService contactManagementService;
     private final ContactDTOMapper contactDTOMapper;

     @Override
     @Transactional
     public void processMessageReceived(FreshDeskPayload freshdeskPayload, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException {

          if (freshdeskPayload.getFreshMessageType() != FreshMessageType.CUSTOMER_CREATION) {
               return;
          }
          log.info("Received ContactCreate message");

          Optional<FreshContact> freshContactOptional = contactDTOMapper.mapDtoFromMessagePayload(freshdeskPayload);

          if (freshContactOptional.isEmpty()) {
               log.error("Error extracting the Freshdesk Contact object from the Queue payload. ");
               throw new FreshdeskProcessorException("Unable to extract the correct payload for message id " + freshReceivedMessageEntity.getFreshMessageId());
          }

          /*
               Now create the contact by submitting the dto payload to Freshdesk
           */
          FreshContact freshContact = freshContactOptional.get();

          contactManagementService.createFreshdeskContact(freshContact, freshReceivedMessageEntity);
     }
}
