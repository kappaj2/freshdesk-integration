package za.co.sfh.fresh.service.freshdesk;

import za.co.sfh.fresh.exception.FreshdeskProcessorException;
import za.co.sfh.fresh.repository.entity.FreshReceivedMessageEntity;
import za.co.sfh.fresh.service.restclient.payloads.FreshContact;
import za.co.sfh.fresh.service.restclient.payloads.FreshContactView;

import java.util.List;
import java.util.Optional;

public interface ContactManagementService {

     Optional<FreshContactView> retrieveContactByEmailAddress(String emailAddress);

     Optional<FreshContactView> retrieveContactByMsisdn(String msisdn);

     Optional<FreshContactView> retrieveContactByExternalId(String externalId);

     List<FreshContactView> retrieveListOfContacts();

     void deleteAllContacts();

//     Optional<FreshContact> createFreshContactDTOFromCRMPayload(FreshDeskPayload freshDeskPayload) throws FreshdeskProcessorException, CustomerNotActiveException;

     void createFreshdeskContact(FreshContact freshContact, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException;

     void updateFreshdeskContact(FreshContactView freshContactView, FreshContact freshContact, FreshReceivedMessageEntity freshReceivedMessageEntity) throws FreshdeskProcessorException;

}
