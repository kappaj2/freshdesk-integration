package za.co.sfh.fresh.exception;

public class FreshdeskProcessorException extends Exception {

     public FreshdeskProcessorException(String message) {
          super(message);
     }
}
