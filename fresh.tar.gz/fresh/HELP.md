# FreshDesk Integration Service

### Reference Documentation
For further reference, please consider the following sections:

* [Freshdesk API Specification](https://developers.freshdesk.com/api/)
* [Freshdesk Data API Speicification](https://developers.freshdesk.com/v2/docs/data-api/)


Setup of Cognito with no user.

A.  Create user pool:
    Name    : SFHBackendPoolDev

B.  Create API Client
    AppClient:
      name      : BACKEND_USER
      clientId  : 6r492q8fro001k5gjtc5roq8nl
      secret    : aqtv6l9barbjjv20btl41lm7jsqchfds6vjt14jqcudprc7uj0t
      refresh token expiration : 30 days.


C.  Create a Domain:
    Domain :
    https://dev-sfh-oauth.auth.us-east-1.amazoncognito.com

D.  Create Resource Server
    Resource server:
      name : DEVELOPER
      identifier: DEVELOPER

      add three scopes:
      ROLES/SUPER, ROLES/DEVELOPER, ROLES/SALES
      
API Gateway
E.   Setup the authorizer to use the new cognito pool.


Get token :
This will get token with all scopes:
=> ROLES/DEVELOPER ROLES/SUPER ROLES/SALES
curl -X POST \
    --user 6r492q8fro001k5gjtc5roq8nl:aqtv6l9barbjjv20btl41lm7jsqchfds6vjt14jqcudprc7uj0t \
    'https://dev-sfh-oauth.auth.eu-west-1.amazoncognito.com/oauth2/token?grant_type=client_credentials' \
    -H 'Content-Type: application/x-www-form-urlencoded'
